
export interface Coordinator {
  id: string;
  name: string;
}
