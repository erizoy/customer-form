

export interface City {
  id: string;
  name: string;
}
